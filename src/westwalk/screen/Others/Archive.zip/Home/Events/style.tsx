import {Dimensions, Platform, StyleSheet} from 'react-native';
import {Colors} from '../../../../theme/Colors';

const {width} = Dimensions.get('window');
const createStyles = (language: string) =>
  StyleSheet.create({
    container: {
      alignItems: 'center',
      marginHorizontal: Platform.OS === 'ios' ? '3%' : '1%',
      marginTop: 10,
    },
    imageContainer: {
      width: width * 0.93,
      height: 350,
      justifyContent: 'center',
      alignItems: 'center',
      marginRight: 4,
    },
    image: {
      width: '100%',
      height: 350,
      borderRadius: 10,
    },
    overlay: {
      position: 'absolute',
      width: '100%',
      height: '100%',
      backgroundColor: 'rgba(0, 0, 0, 0.3)',
      padding: '4%',
      justifyContent: 'flex-end',
      alignItems: 'flex-end',
      borderRadius: 20,
    },
    imageText: {
      color: 'white',
      fontSize: 18,
      fontWeight: 'bold',
    },
    pagination: {
      flexDirection: 'row',
      marginTop: 10,
    },
    dot: {
      width: 8,
      height: 8,
      borderRadius: 4,
      marginHorizontal: 2,
    },
    loader: {
      position: 'absolute',
      alignSelf: 'center',
      justifyContent: 'center',
    },
  });

const languageStyles = new Map<string, ReturnType<typeof createStyles>>();
export const getStyles = (language: string | String) => {
  const key = String(language);
  let cached = languageStyles.get(key);
  if (!cached) {
    cached = createStyles(key);
    languageStyles.set(key, cached);
  }
  return cached;
};
